import React, { Component } from 'react';
import CountryContainer from './containers/CountryContainer';

class App extends Component {
  render() {
    return (
      <CountryContainer />
    );
  }
}

export default App;
