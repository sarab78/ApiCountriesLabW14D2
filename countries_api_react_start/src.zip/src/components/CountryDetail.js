import React from 'react';

const CountryDetail = () => {
  return (
    <h3>
      Country details to go here.
    </h3>
  )
}

export default CountryDetail;
